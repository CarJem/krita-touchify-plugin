from PyQt5.QtWidgets import QStackedWidget, QWidget, QVBoxLayout, QHBoxLayout, QTabBar, QSizePolicy, QPushButton, QDialog
from PyQt5.QtCore import QEvent

from touchify.src.managers.shared.resources import ResourceManager


class PropertyGrid(QWidget):


    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.our_layout = QVBoxLayout(self)
        self.our_layout.setSpacing(0)
        self.our_layout.setContentsMargins(0,0,0,0)
        self.setLayout(self.our_layout)

        self.navi_connection = None

        self.naviBarRow = QWidget(self)
        self.naviBarRow.setContentsMargins(0,0,0,0)
        self.naviBarLayout = QHBoxLayout(self.naviBarRow)
        self.naviBarLayout.setSpacing(0)
        self.naviBarLayout.setContentsMargins(0,0,0,0)
        self.naviBarRow.setLayout(self.naviBarLayout)
        self.our_layout.addWidget(self.naviBarRow)

        self.naviBarBackBtn = QPushButton(self.naviBarRow)
        self.naviBarBackBtn.setContentsMargins(0,0,0,0)
        self.naviBarBackBtn.setFlat(True)
        self.naviBarBackBtn.setIcon(ResourceManager.materialIcon("arrow-left"))
        self.naviBarBackBtn.clicked.connect(self.goBack)
        self.naviBarLayout.addWidget(self.naviBarBackBtn)

        self.naviTabBar = QTabBar(self.naviBarRow)
        self.naviTabBar.setExpanding(False)
        self.naviTabBar.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        self.naviTabBar.setMovable(False)
        self.naviTabBar.setUsesScrollButtons(True)
        self.naviTabBar.installEventFilter(self)
        self.naviTabBar.setTabsClosable(False)
        self.naviBarLayout.addWidget(self.naviTabBar, 1)

        self.variable_path: list[str] = []

        from .PropertyPage import PropertyPage
        self.rootPropertyGrid = PropertyPage(self)
        self.rootPropertyGrid.setWindowTitle("ROOT")

        self.stackWidget = QStackedWidget(self)
        self.stackWidget.insertWidget(0, self.rootPropertyGrid)
        self.our_layout.addWidget(self.stackWidget)

        self.updateNavigationTabs()


    def eventFilter(self, obj, event):
        if obj is self.naviTabBar and event.type() == QEvent.Type.Wheel:
            return True
        return super(PropertyGrid, self).eventFilter(obj, event)


    def navigationIndexChanged(self):
        tabIndex = self.naviTabBar.currentIndex()
        stackIndex = self.stackWidget.currentIndex()

        if stackIndex > tabIndex:
            navigate_back_amount = stackIndex - tabIndex
            self.goBack(navigate_back_amount)
        
    def setNavigationConnection(self, s: bool):
        if s and self.navi_connection == None:
            self.navi_connection = self.naviTabBar.currentChanged.connect(self.navigationIndexChanged)
        elif self.navi_connection and s == False:
            self.naviTabBar.currentChanged.disconnect(self.navigationIndexChanged)
            self.navi_connection = None

    def updateNavigationTabs(self):
        self.setNavigationConnection(False)
        while self.naviTabBar.count() != 0:
            self.naviTabBar.removeTab(0)

        for i in range(0, self.stackWidget.count()):
            item = self.stackWidget.widget(i)
            self.naviTabBar.addTab(item.windowTitle())

        self.naviTabBar.setCurrentIndex(self.stackWidget.currentIndex())
        self.naviTabBar.scroll(self.naviTabBar.width(), 0)
        self.setNavigationConnection(True)

    def currentIndex(self):
        return self.stackWidget.currentIndex()
    
    def currentWidget(self):
        return self.stackWidget.currentWidget()

    def addWidget(self, w: QWidget):
        return self.stackWidget.addWidget(w)

    def setCurrentIndex(self, index):
        self.setNavigationConnection(False)
        self.stackWidget.setCurrentIndex(index)
        self.updateNavigationTabs()
    
    def updateDataObject(self, data: any):
        self.rootPropertyGrid.updateDataObject(data)
        self.updateNavigationTabs()

    def goForward(self, newPage):
        self.setNavigationConnection(False)
        self.setCurrentIndex(self.addWidget(newPage))
        self.updateNavigationTabs()


    def goBack(self, amount: int = 1):
        if self.stackWidget.count() == 1: return

        if amount < 1: amount = 1
        self.setNavigationConnection(False)
        for i in range(0, amount):
            lastIndex = self.currentIndex() - 1
            currentWidget = self.currentWidget()
            if isinstance(currentWidget, QDialog):
                currentWidget.reject()
            self.setCurrentIndex(lastIndex)
            self.stackWidget.removeWidget(currentWidget)
        self.updateNavigationTabs()