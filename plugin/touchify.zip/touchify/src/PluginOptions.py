
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from touchify.src.api_krita.wrappers.window import WindowAPI
from touchify.src.components.property_grid.PropertyGrid import PropertyGrid
from touchify.src.managers.shared.settings import TouchifySettings
import copy

from krita import *

class PluginOptions(QDialog):

    def __init__(self, qwin: WindowAPI):
        super().__init__(qwin.qwindow.window())
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose)
        self.qwin = qwin.qwindow
        
        self.editableConfig = copy.deepcopy(TouchifySettings.instance().getConfig())
        self.propertyGrid = PropertyGrid(self)
        self.propertyGrid.updateDataObject(self.editableConfig)

        self.container = QVBoxLayout(self)
        self.setMinimumSize(600,400)
        self.setBaseSize(800,800)

        self.btns = QDialogButtonBox(self)
        self.btns.addButton(QDialogButtonBox.StandardButton.Save).clicked.connect(self.onSave)
        self.btns.addButton(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.onApply)
        self.btns.addButton(QDialogButtonBox.StandardButton.Close).clicked.connect(self.onClose)

        self.container.addWidget(self.propertyGrid)
        self.container.addWidget(self.btns)
        self.setLayout(self.container)     
    
    def _saveFile(self):
        self.editableConfig.save()
        TouchifySettings.reload()

    def onSave(self):
        self._saveFile()
        self.accept()

    def onApply(self):
        self.btns.setEnabled(False)
        QTimer.singleShot(5000, lambda: self.btns.setDisabled(False))

        self._saveFile()

    def onClose(self):
        self.close()
        self.reject()

