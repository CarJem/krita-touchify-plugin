from typing import TYPE_CHECKING
from PyQt5 import *
from PyQt5.QtWidgets import *
from krita import *

from touchify.src.PluginManagers import TouchifyManagers
from touchify.src.api_krita.wrappers.window import WindowAPI
from touchify.__env__ import *

from touchify.src.PluginOptions import PluginOptions


import touchify.src.extensions.pyqt_extensions as PyQtExtensions


WINDOW_ID: int = 0
if TYPE_CHECKING:
    from .Plugin import TouchifyPlugin

class TouchifyWindow(QObject):
    

    def __init__(self, parent: QObject):
        super().__init__(parent)

        global WINDOW_ID; self.INSTANCE_ID = WINDOW_ID; WINDOW_ID += 1
        self.managers = TouchifyManagers(self)
        self.dlg_settings: PluginOptions | None = None

    def Load(self, window: WindowAPI):
        self.api_window = window
        self.setParent(self.api_window.qwindow)
        self.managers.Load(self)

        self.action_plugin_instance = QAction(f"Instance: #{self.INSTANCE_ID}", self.action_plugin_tools_menu)
        self.action_plugin_instance.setEnabled(False)
        self.action_plugin_instance.setSeparator(True)
        self.action_plugin_tools_menu.addAction(self.action_plugin_instance)
        self.managers.ActionWidgets(self)

        self.managers.Addons(self)

    def LoadActions(self, window: WindowAPI):
        self.action_plugin_settings = window.create_action(TOUCHIFY_ACTIONID_CONFIGURE, "Configure Touchify...", "settings")
        self.action_plugin_settings.triggered.connect(self.OpenSettings)

        self.action_plugin_tools_menu = QMenu(None, window.qwindow)
        self.action_plugin_tools = window.create_action("touchify", "Touchify", "tools")
        self.action_plugin_tools.setMenu(self.action_plugin_tools_menu)

        self.managers.Actions(window)
 
    def Unload(self):
        pass

    def OpenSettings(self):
        if self.dlg_settings != None:
            if PyQtExtensions.CommonHelpers.isDeleted(self.dlg_settings) == False:
                return
          
        self.dlg_settings = PluginOptions(self.api_window)
        self.dlg_settings.show()