
from PyQt5.QtWidgets import QWidget
from krita import *
from PyQt5.QtCore import *

from touchify.src.api_krita.wrappers.docker_factory import DockWidgetFactoryAPI
from touchify.src.components.widgets.BrushFlowSlider import BrushFlowSlider
from touchify.src.components.widgets.BrushOpacitySlider import BrushOpacitySlider
from touchify.src.components.widgets.BrushRotationSlider import BrushRotationSlider
from touchify.src.components.widgets.BrushSizeSlider import BrushSizeSlider
from touchify.__env__ import *

from touchify.src.managers.shared.settings_krita import *
from touchify.src.components.krita.KisSliderSpinBox import KisSliderSpinBox

DOCKER_TITLE = 'Touchify Addon: Brush Options'
DOCKER_ID = "Touchify/BrushOptionsDocker"

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from touchify.src.PluginWindow import TouchifyWindow

class BrushOptionsDockerCfg:

    def __init__(self):
        self.ShowFlowSlider = KritaSettings.readSettingBool(DOCKER_ID, "ShowFlowSlider", True)
        self.ShowOpacitySlider = KritaSettings.readSettingBool(DOCKER_ID, "ShowOpacitySlider", True)
        self.ShowSizeSlider = KritaSettings.readSettingBool(DOCKER_ID, "ShowSizeSlider", True)
        self.ShowRotationSlider = KritaSettings.readSettingBool(DOCKER_ID, "ShowRotationSlider", True)

    def toggle(self, setting: str):
        if hasattr(self, setting):
            currentValue = getattr(self, setting)
            currentValue = not currentValue
            setattr(self, setting, currentValue)
            self.save()


    def save(self):
        KritaSettings.writeSettingBool(DOCKER_ID, "ShowFlowSlider", self.ShowFlowSlider)
        KritaSettings.writeSettingBool(DOCKER_ID, "ShowOpacitySlider", self.ShowOpacitySlider)
        KritaSettings.writeSettingBool(DOCKER_ID, "ShowSizeSlider", self.ShowSizeSlider)
        KritaSettings.writeSettingBool(DOCKER_ID, "ShowRotationSlider", self.ShowRotationSlider)

class BrushOptionsWidget(QWidget):
    def __init__(self, parent: QWidget | None = None):
        super(BrushOptionsWidget, self).__init__(parent)

        self.app_window: "TouchifyWindow" = None

        self.config = BrushOptionsDockerCfg()
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)

        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self.gridLayout = QVBoxLayout(self)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setContentsMargins(0,0,0,0)

        self.sizeSlider = BrushSizeSlider(self)
        self.opacitySlider = BrushOpacitySlider(self)
        self.flowSlider = BrushFlowSlider(self)
        self.rotationSlider = BrushRotationSlider(self)

        self.optionsMenu = self.genMenu()
        self.optionsButton = QPushButton(self)
        self.optionsButton.setIcon(KritaAPI.get_icon("configure"))
        self.optionsButton.setMenu(self.optionsMenu)
        self.optionsButton.setFixedHeight(15)
        self.optionsButton.setStyleSheet(f"""QPushButton::menu-indicator {{ image: none; }} QToolButton::menu-indicator {{ image: none; }}""")
        self.optionsButton.clicked.connect(self.optionsButton.showMenu)
        self.gridLayout.addWidget(self.optionsButton)
        
        self.gridLayout.addWidget(self.sizeSlider)
        self.gridLayout.addWidget(self.opacitySlider)
        self.gridLayout.addWidget(self.flowSlider)
        self.gridLayout.addWidget(self.rotationSlider)
        self.gridLayout.addWidget(self.optionsButton)

        self.updateSliders()

    def setup(self, app_window: "TouchifyWindow"):
        self.app_window = app_window
        
        self.sizeSlider.setInstance(self.app_window.api_window)
        self.opacitySlider.setInstance(self.app_window.api_window)
        self.flowSlider.setInstance(self.app_window.api_window)
        self.rotationSlider.setInstance(self.app_window.api_window)

        self.updateSliders()

    def genMenu(self):
        menu = QMenu()
        sect = menu.addSeparator()
        sect.setText("Show:")

        sizeToggle = menu.addAction("Size")
        sizeToggle.setCheckable(True)
        sizeToggle.setChecked(self.config.ShowSizeSlider)
        sizeToggle.toggled.connect(lambda: self.toggleSlider("ShowSizeSlider"))

        opacityToggle = menu.addAction("Opacity")
        opacityToggle.setCheckable(True)
        opacityToggle.setChecked(self.config.ShowOpacitySlider)
        opacityToggle.toggled.connect(lambda: self.toggleSlider("ShowOpacitySlider"))

        flowToggle = menu.addAction("Flow")
        flowToggle.setCheckable(True)
        flowToggle.setChecked(self.config.ShowFlowSlider)
        flowToggle.toggled.connect(lambda: self.toggleSlider("ShowFlowSlider"))

        rotationToggle = menu.addAction("Rotation")
        rotationToggle.setCheckable(True)
        rotationToggle.setChecked(self.config.ShowRotationSlider)
        rotationToggle.toggled.connect(lambda: self.toggleSlider("ShowRotationSlider"))

        return menu

    
    def toggleSlider(self, setting: str):
        self.config.toggle(setting)
        self.updateSliders()

    def updateSliders(self):

        def updateSliderVisibility(option: bool, slider: KisSliderSpinBox):
            if option:
                slider.show()
                slider.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
                slider.updateGeometry()
                slider.adjustSize()
            else:
                slider.hide()
                slider.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)
                slider.updateGeometry()
                slider.adjustSize()

        updateSliderVisibility(self.config.ShowSizeSlider, self.sizeSlider)
        updateSliderVisibility(self.config.ShowOpacitySlider, self.opacitySlider)
        updateSliderVisibility(self.config.ShowFlowSlider, self.flowSlider)
        updateSliderVisibility(self.config.ShowRotationSlider, self.rotationSlider)
        
    def showEvent(self, event):
        super().showEvent(event)

    def closeEvent(self, event):
        super().closeEvent(event)

    def onCanvasChanged(self, canvas: Canvas):
        self.updateSliders()

class BrushOptionsDocker(DockWidget):

    def __init__(self): 
        super().__init__()
        self.setWindowTitle(DOCKER_TITLE)
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self.brushOptions = BrushOptionsWidget(self)
        self.setWidget(self.brushOptions)

    def TOUCHIFY_ADDON_SETUP(self, instance: "TouchifyWindow"):
        self.brushOptions.setup(instance)

    def showEvent(self, event):
        super().showEvent(event)

    def closeEvent(self, event):
        super().closeEvent(event)
    
    # notifies when views are added or removed
    # 'pass' means do not do anything
    def canvasChanged(self, canvas):
        self.brushOptions.onCanvasChanged(canvas)

KritaAPI.add_dock_widget_factory(DOCKER_ID, DockWidgetFactoryAPI.DockPosition.DockRight, BrushOptionsDocker)
